#!/bin/bash
SCRIPT_NAME="$(basename "$0")"
SCRIPT_DIR="$(dirname "$(readlink -f "$0")")"

_IS_UPGRADE=0
_PARAM_SET=0
UFM_HA_BACKUP_DIR="/opt/backup/ufm_ha"

# shellcheck source=.install_common.sh
. "${SCRIPT_DIR}/.install_common.sh"

usage() {
    local csv_products
    printf -v csv_products '%s, ' "${VALID_PRODUCTS[@]}"
    # use ::-2 to remove last ', '
    csv_products="${csv_products::-2}"

    cat << EOF
Usage: ${SCRIPT_NAME} -h | -u | -p <product> [ -l <sync-dir> ] [ -d <partition> ]

The "${SCRIPT_NAME}" script installs UFM HA plugin for UFM products (see below).

OPTIONS:
    -u | --upgrade                  Upgrade ufm-ha scripts (no additional parameters needed).
    -l | --sync-dir                 Directory used to mount and sync files.
         --drbd-location            alias for --sync-dir (for backward compatibility).
    -d | --drbd-disk                Name of disk partition for DRBD, for example: /dev/sdd4.
    -p | --product                  Name of UFM product to run in HA mode. Must be one of:
                                    ${csv_products}
    -h | --help                     Show this message.

EOF
}

_validate_options() {
    if [[ -z ${PRODUCT_TYPE} ]]; then
        echo "Error: missing product name!"
        usage
        exit 1
    else
        validate_product
    fi
    # For now, drbd-disk and drbd-location are not required in Appliance product
    local appliance_products
    appliance_products=("${PRODUCT_CYBER_AI}" "${PRODUCT_UFM_CYBER_AI}" "${PRODUCT_ENTERPRISE_APPLIANCE}")
    if [[ ! " ${appliance_products[*]} " =~ \ ${PRODUCT_TYPE}\  ]]; then
        if [[ -z ${DATA_SYNC_DIR} ]]; then
            echo "Error: missing sync-dir/drbd-location!"
            usage
            exit 1
        fi
    fi

    if [ -n "${DRBD_DISK}" ]; then
        validate_drbd_disk "${DRBD_DISK}"
    fi

    if [ -n "${DATA_SYNC_DIR}" ]; then
        validate_sync_dir "${DATA_SYNC_DIR}"
    fi
}

parse_options() {

    local short_opts="l:d:p:uh"
    local long_opts="sync-dir:,drbd-location:,drbd-disk:,product:,upgrade,help"
    local options
    
    if ! options=$(getopt -n "${SCRIPT_NAME}" -o ${short_opts} --long ${long_opts} -- "$@"); then
      usage
      exit 1
    fi

    eval set -- "$options"
    while true
    do
        case "$1" in
            -u | --upgrade)
                _IS_UPGRADE=1
                shift
                ;;
            -l | --sync-dir | --drbd-location)
                DATA_SYNC_DIR=$2
                _PARAM_SET=1
                shift 2
                ;;
            -d | --drbd-disk)
                DRBD_DISK=$2
                _PARAM_SET=1
                shift 2
                ;;
            -p | --product)
                PRODUCT_TYPE=$2
                _PARAM_SET=1
                shift 2
                ;;
            -h | --help)
                usage
                exit 0
                ;;
            --)
                shift
                break
                ;;
        esac
    done
    if [ ${_IS_UPGRADE} -eq 0 ]; then
        _validate_options
    else
        if [ ${_PARAM_SET} -eq 1 ]; then
            echo "No arguments are allowed with '--upgrade' option"
            exit 1
        fi
    fi
}

#######################################################################
#                Installation Main Logic                              #
#######################################################################
parse_options "$@"
if ! verify_os; then
    exit 1
fi
if check_installed; then
    # HA is installed, but no upgrade flag
    if [ ${_IS_UPGRADE} -eq 0 ]; then
        echo "An older version of ufm_ha exists, either run with '--upgrade' or uninstall and reinstall!"
        exit 1
    fi
    if [ -f "${LEGACY_UFM_HA_CONF_FILE}" ]; then
        # legacy ufm-ha
        # read drbd disk to check drbd installation
        DRBD_DISK=$(get_legacy_config "disk")
        DATA_SYNC_DIR=$(get_legacy_config "sync_dir")
        if [ -z "${DATA_SYNC_DIR}" ]; then
            DATA_SYNC_DIR=$(get_legacy_config "location")
        fi
        PRODUCT_TYPE=$(get_legacy_config "type")
        if [ -z "${PRODUCT_TYPE}" ]; then
            if ! PRODUCT_TYPE=$(get_legacy_product_type); then
                echo "Could not find product type!"
                exit 1
            fi
        fi
        export CONFIG_VERSION
        CONFIG_VERSION=$(get_legacy_config "version")
        export CURRENT_NODE_IP
        CURRENT_NODE_IP=$(get_legacy_config "current_node_ip")
    elif [ -f "${UFM_HA_CONF_FILE}" ]; then
        # shellcheck disable=SC1090
        . "${UFM_HA_CONF_FILE}"
    fi
else
    # HA is not installed, and have upgrade flag
    if [ ${_IS_UPGRADE} -eq 1 ]; then
        echo "No older version found for upgrade!"
        exit 1
    fi
fi

if [ ! -d "${LOG_DIR}" ]; then
    mkdir "${LOG_DIR}"
fi

touch "${INSTALL_LOG}"
log_msg "================================================"
log_msg "$(date)"
log_msg "================================================"
log_msg " [*] Installing UFM HA for ${PRODUCT_TYPE} [*]"
log_msg " -----------------------------------------------"

if [ ${_IS_UPGRADE} -eq 1 ]; then
    prepare_upgrade
    backup_legacy_ufm_ha
else
    log_msg "[*] Disabling pcs UI"
    disable_pcs_gui
fi

pushd "${SCRIPT_DIR}" > /dev/null || { echo "Failed to change to dir: ${SCRIPT_DIR}" && exit 1; }

trap cleanup_install EXIT

log_msg "[*] Installing package files"
if ! install_package; then
    restore_legacy_ufm_ha
    log_msg "Installation failed"
    exit 1
else
    remove_legacy_ufm_ha
fi

if [ ${_IS_UPGRADE} -eq 1 ]; then
    adjust_ha_config
fi

if [ -z "${DRBD_DISK}" ]; then
    _appliance_products=("${PRODUCT_CYBER_AI}" "${PRODUCT_UFM_CYBER_AI}" "${PRODUCT_ENTERPRISE_APPLIANCE}")
    if [[ ! " ${_appliance_products[*]} " =~ \ ${PRODUCT_TYPE}\  ]]; then
        log_msg "Note: HA has been installed without DRBD support, you won't be able to configure HA using DRBD."
    fi
fi

ufm_backup_dir="${UFM_HA_BACKUP_DIR}/backup_${UFM_HA_VERSION}"
if ! backup_installation_files "$ufm_backup_dir"; then
    log_msg "Backup Installation failed"
    exit 1
fi

log_msg "Done. Please run: 'systemctl daemon-reload' to load new HA services"
log_msg "To See full installation logs please check: ${INSTALL_LOG}"
