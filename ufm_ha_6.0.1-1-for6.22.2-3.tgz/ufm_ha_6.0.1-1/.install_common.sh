#!/bin/bash
LOG_DIR="/var/log/ufm_ha"
INSTALL_LOG="${LOG_DIR}/ufm_ha_install_$(date +%Y%m%d_%H%M).log"

PREV_INSTALLED_HA=
UFM_HA_VERSION="6.0.1-1"


# UFM Product Names
PRODUCT_CYBER_AI="cyber-ai"
PRODUCT_ENTERPRISE="enterprise"
PRODUCT_TELEMETRY="telemetry"
PRODUCT_UFM_CYBER_AI="ufm-cyber-ai"
PRODUCT_ENTERPRISE_APPLIANCE="enterprise-appliance"
PRODUCT_ENTERPRISE_MULTINODE="enterprise-multinode"

# Legacy ufm-ha content
local_bin_content=("ufm_ha_cluster" "ufm_ha_watcher" "configure_ha_nodes.sh" "telemetry_watcher"
                   "replace_ha_nodes.sh" "ha_multilink_patch.sh" "ufm_enterprise_utility.sh" "ha_utils")
usr_bin_content=("vsysinfo" "ufm_sysdump.sh")
services=("ufm-ha-watcher.service" "telemetry-watcher.service")
sysdump_conf=("ufm-ha-sysdump.conf" "vsysinfo.host.conf")
LOCAL_BIN_DIR="/usr/local/bin"
SERVICES_DIR="/etc/systemd/system"
UFM_HA_INSTALL_DIR="/opt/ufm_ha"
UFM_SYSDUMP_DIR="/etc/ufm/"
USR_BIN_DIR="/usr/bin"

BACKUP_METADATA_FILE=
export BACKUP_HA_NODES_CFG=
LEGACY_UFM_HA_CONF_FILE="${LOCAL_BIN_DIR}/ha_utils/ufm-ha.conf"
LEGACY_UFM_HA_CLUSTER="${LOCAL_BIN_DIR}/ufm_ha_cluster"
export UFM_HA_CONF_FILE="/usr/bin/ha_utils/ufm-ha-conf.sh"

VALID_PRODUCTS=("${PRODUCT_ENTERPRISE}" "${PRODUCT_ENTERPRISE_APPLIANCE}" "${PRODUCT_CYBER_AI}" \
    "${PRODUCT_UFM_CYBER_AI}" "${PRODUCT_TELEMETRY}" "${PRODUCT_ENTERPRISE_MULTINODE}")

INSTALL_PKG_FUNC=
CHECK_PKG_FUNC=
UFM_HA_PKG=

cleanup_install() {
    popd > /dev/null || { echo "Failed to popd" && exit 1; }
}

log_msg(){
    echo "$@" | tee -a "${INSTALL_LOG}"
}

get_legacy_config() {
    grep -E ^"$1" "${LEGACY_UFM_HA_CONF_FILE}" | awk -F= '{print $2}' | tr -d ' '
}

get_legacy_product_type() {
    local systemd_services
    systemd_services=$(get_legacy_config "systemd_services")
    if [[ "${systemd_services}" =~ "ufm-cyberai" ]]; then
        if [[ "${systemd_services}" =~ "ufm-enterprise" ]]; then
            echo "${PRODUCT_CYBER_AI}"
        else
            echo "${PRODUCT_UFM_CYBER_AI}"
        fi
    elif [[ "${systemd_services}" =~ "ufm-enterprise" ]]; then
        if [ -f /etc/ufm-release ]; then
            echo "${PRODUCT_ENTERPRISE_APPLIANCE}"
        else
            echo "${PRODUCT_ENTERPRISE}"
        fi
    elif [[ "${systemd_services}" =~ "ufm-telemetry" ]]; then
        echo "${PRODUCT_TELEMETRY}"
    else
        echo "Unknown product"
        return 1
    fi
    return 0
}

_install_rpm() {
    log_msg "Installing RPM Package (OS=$ID)."
    rpm_flags="-ivh"
    if _check_rpm "ufm-ha"; then
        rpm_flags="-Uvh"
    fi
    rpm --replacefiles $rpm_flags ufm-ha*.rpm | tee -a "${INSTALL_LOG}"
    return "${PIPESTATUS[0]}"
}

_install_dpkg() {
    log_msg "Installing Debian Package (OS=$ID)."
    dpkg --force-overwrite --force-confnew -i ufm-ha*.deb | tee -a "${INSTALL_LOG}"
    return "${PIPESTATUS[0]}"
}

install_package() {
    export PRODUCT_TYPE
    export DRBD_DISK
    export DATA_SYNC_DIR
    export BACKUP_HA_NODES_CFG
    export CONFIG_VERSION
    export CURRENT_NODE_IP
    ${INSTALL_PKG_FUNC}
}

backup_installation_files() {
    local backup_dir="$1"

    # Create the UFM HA backup subdirectory
    if ! mkdir -p "$backup_dir"; then
        log_msg "Error: Failed to create UFM HA backup directory '$backup_dir'"
        return 1
    fi

    for file_name in "install.sh" ".install_common.sh"; do
        if ! cp -a "$file_name" "$backup_dir/"; then
            log_msg "Error: Failed to copy $file_name"
            return 1
        fi
    done

    local matches=()
    mapfile -t matches < <(compgen -G "$UFM_HA_PKG")

    if (( ${#matches[@]} != 1 )); then
        echo "Error: Expected exactly one match for pattern '$UFM_HA_PKG', found ${#matches[@]}"
        return 1
    fi
    local pkg_file="${matches[0]}"

    log_msg "Backing up package file(s): $pkg_file ==> $backup_dir"
    cp -a "$pkg_file" "$backup_dir/" || {
        log_msg "Error: Failed to copy package file(s)."
        return 1
    }

    log_msg "Installation files successfully backed up to $backup_dir."
    return 0
}

verify_os() {
    # shellcheck disable=SC1091
    . /etc/os-release
    if [[ "${ID}" == "ubuntu" ||  "${ID}" == "debian" ]]; then
        INSTALL_PKG_FUNC=_install_dpkg
        CHECK_PKG_FUNC=_check_dpkg
        UFM_HA_PKG="ufm-ha*.deb"
    elif [[ ${ID} == "rhel" || ${ID} == "centos" || ${ID} == "rocky" || ${ID} == "ol" ]]; then
        INSTALL_PKG_FUNC=_install_rpm
        CHECK_PKG_FUNC=_check_rpm
        UFM_HA_PKG="ufm-ha*.rpm"
    else
        log_msg "Warning: Unsupported OS"
        return 1
    fi
}

_backup_fs_node() {
    local fs_node_path="$1"
    local backup_node_path="${fs_node_path}.bak"
    # chech if file/dir exists
    if [ -e "${fs_node_path}" ]; then
        echo "${fs_node_path}" >> "${BACKUP_METADATA_FILE}"
        # remove old backup, just in case
        if [ -d "${backup_node_path}" ]; then
            rm -rf "${backup_node_path}"
        elif [ -f "${backup_node_path}" ]; then
            rm -f "${backup_node_path}"
        fi
        mv "${fs_node_path}" "${backup_node_path}"
    fi
}

backup_legacy_ufm_ha() {
    if [ ! -f "${LEGACY_UFM_HA_CONF_FILE}" ]; then
        return 0
    fi
    local fs_node
    local fs_node_path
    BACKUP_METADATA_FILE="$(mktemp --suffix ".txt" -p /tmp ufm_ha_metadata_XXXXXXX)"
    for fs_node in "${local_bin_content[@]}"; do
        fs_node_path="${LOCAL_BIN_DIR}/${fs_node}"
        _backup_fs_node "${fs_node_path}"
    done
    for fs_node in "${services[@]}"; do
        fs_node_path="${SERVICES_DIR}/${fs_node}"
        _backup_fs_node "${fs_node_path}"
    done
    for fs_node in "${usr_bin_content[@]}"; do
        fs_node_path="${USR_BIN_DIR}/${fs_node}"
        _backup_fs_node "${fs_node_path}"
    done
    for fs_node in "${sysdump_conf[@]}"; do
        fs_node_path="${UFM_SYSDUMP_DIR}/${fs_node}"
        _backup_fs_node "${fs_node_path}"
    done
    fs_node_path="${UFM_HA_INSTALL_DIR}"
    _backup_fs_node "${fs_node_path}"

    fs_node_path="/etc/ha_nodes.cfg"
    if [ -f "${fs_node_path}" ]; then
        _backup_fs_node "${fs_node_path}"
    fi
    BACKUP_HA_NODES_CFG="${fs_node_path}.bak"
}

remove_legacy_ufm_ha() {
    local backup_node_path
    local fs_node_path
    if [ -z "${BACKUP_METADATA_FILE}" ]; then
        return 0
    fi
    while read -r fs_node_path; do
        backup_node_path="${fs_node_path}.bak"
        if [ -d "${backup_node_path}" ]; then
            rm -rf "${backup_node_path}"
        elif [ -f "${backup_node_path}" ]; then
            rm -f "${backup_node_path}"
        fi
    done < "${BACKUP_METADATA_FILE}"
    rm -f "${BACKUP_METADATA_FILE}"
    # clear bash cache, because ufm_ha_cluster moved from /usr/local/bin to /usr/bin
    hash -d ufm_ha_cluster configure_ha_nodes.sh cleanup_ha_nodes.sh replace_ha_nodes.sh ufm_enterprise_utility.sh 2> /dev/null
}

restore_legacy_ufm_ha() {
    local backup_node_path
    local fs_node_path
    if [ -z "${BACKUP_METADATA_FILE}" ]; then
        return 0
    fi
    while read -r fs_node_path; do
        backup_node_path="${fs_node_path}.bak"
        # remove new entries in case of some leftovers
        if [ -d "${fs_node_path}" ]; then
            rm -rf "${fs_node_path}"
        elif [ -f "${fs_node_path}" ]; then
            rm -f "${fs_node_path}"
        fi
        mv -f "${backup_node_path}" "${fs_node_path}"
    done
    rm -f "${BACKUP_METADATA_FILE}"
}

disable_pcs_gui() {
    local pcsd_config="/etc/default/pcsd"
    if [ -f ${pcsd_config} ]; then
        gui_attr=$(grep PCSD_DISABLE_GUI ${pcsd_config})
        if [ "${gui_attr}" != "" ]; then
            sed -i 's/PCSD_DISABLE_GUI=false/PCSD_DISABLE_GUI=true/g' ${pcsd_config}
        else
            echo "PCSD_DISABLE_GUI=true" >> ${pcsd_config}
        fi
     fi
}

validate_product() {
    if [[ ! " ${VALID_PRODUCTS[*]} " =~ \ ${PRODUCT_TYPE}\  ]]; then
        # replace ' ' with ', '
        printf -v joined_products '%s, ' "${VALID_PRODUCTS[@]}"
        # use ::-2 to remove last ', '
        echo "Invalid product name! Please one of: ${joined_products::-2}"
        exit 1
    fi
}

validate_sync_dir() {
    local sync_dir="$1"
    echo "Validating sync directory ${sync_dir}"
    # Check if the directory exists
    if [ ! -d "${sync_dir}" ] ; then
        echo "Error: Cannot find ${sync_dir} data directory."
        exit 1
    fi
}

validate_drbd_disk() {
    local disk="$1"
    echo "Validating DRBD disk ${disk}"

    # Check if drbd disk exists
    if [ ! -e "${disk}" ]; then
        echo "Error: Drbd disk ${disk} does not exist."
        exit 1
    fi
    # Check if the drbd disk is a block device
    if [ ! -b "${disk}" ] ; then
        echo "Error: Drbd disk ${disk} is not a block device."
        exit 1
    fi
}

_compare_versions(){
    version1=$1
    version2=$2
    if [[ "$version1" == "$version2" ]]; then
        echo '='
    else
        if [[ $(echo -e "$version1\n$version2" | sort -V | tail -n1) == "$version1" ]]; then
            echo '>'
        else
            echo '<'
        fi
    fi
}

_check_dpkg() {
    local pkg="$1"
    test "$(dpkg -s "${pkg}" 2>/dev/null | grep Status | awk '{print $4}')" == "installed"
}

_check_rpm() {
    local pkg="$1"
    rpm -q "${pkg}"  -i > /dev/null 2>&1
}

_check_package_install() {
    local pkg="ufm-ha"
    ${CHECK_PKG_FUNC} "${pkg}"
}

check_installed() {
    if ! _check_package_install; then
        test -f "${LEGACY_UFM_HA_CLUSTER}"
    fi
}

prepare_upgrade() {
    if [ ! -f "${LEGACY_UFM_HA_CONF_FILE}" ] || [ ! -f "${LEGACY_UFM_HA_CLUSTER}" ]; then
        return 0
    fi
    local old_confs=0
    PREV_INSTALLED_HA=$(grep 'UFM_HA_VERSION=' "${LEGACY_UFM_HA_CLUSTER}" | sed 's/"//g' | awk -F= '{print $NF}')

    compare_res=$(_compare_versions "${UFM_HA_VERSION}" "$PREV_INSTALLED_HA")
    if [ "${compare_res}" == ">" ]; then
        # Upgrade
        old_configuration_res=$(_compare_versions "5.1.0-4" "${PREV_INSTALLED_HA}")
        if [ "${old_configuration_res}" == ">" ]; then
            # Upgrade from legacy configurtions.
            old_confs=1
        fi
    fi
    if [ ${old_confs} -eq 1 ]; then
        log_msg "Warning: There are major changes in the HA settings, please reconfigure the HA cluster prior to starting it."
    else
        if [ -n "$PREV_INSTALLED_HA" ] && [ -n "$UFM_HA_VERSION" ]; then
            if pcs status 2>/dev/null | grep ufmcluster &>/dev/null; then
                CONFIG_VERSION="${UFM_HA_VERSION}"
            fi
        fi
    fi
}

adjust_ha_config() {
    log_msg "Adjusting HA configuration if needed."
    /usr/bin/ufm_ha_cluster adjust-config
}
